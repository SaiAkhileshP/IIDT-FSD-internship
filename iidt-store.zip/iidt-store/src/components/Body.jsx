import React, { useState } from 'react'
import products from '../Products.json'

export const Body = () => {
const [input,setInput] = useState('')

const handleIkea = () =>{
    setInput("ikea");
}
const handleMarcos = () =>{
    setInput("marcos");
}
const handleCaressa = () =>{
    setInput("caressa");
}
const handleLiddy = () =>{
    setInput("liddy");
}
console.log(input);
  return (
    <div className='container'>
        <div className="sidebar">
           <input type="text" id="" placeholder='Search By Company Name' value={input} onChange={(e) => setInput(e.target.value)}/>
          <div className="btns">
             <button onClick={()=>{setInput('')}}>All</button>
           <button onClick={handleIkea}>Ikea</button>
           <button onClick={handleMarcos}>Marcos</button>
           <button onClick={handleCaressa}>Caressa</button>
           <button onClick={handleLiddy}>Liddy</button>
          </div>
           
        </div>
        <div className="main">
            {products.filter(products => products.company.includes(input)).map(pro => {
                return <div className='box'>
                    <img src={pro.image} alt="" />
                    <h3>{pro.title}</h3>
                    <p>{pro.price}</p>
                </div>
            })}
        </div>
    </div>
  )
}
