
const Header = () => {
  return (
    <div className='header'>
        <h1 className='heading'>Google Books Store</h1>
        <p>-: IIDT FSD Internship Assignment :-</p>
    </div>
  )
}

export default Header;
