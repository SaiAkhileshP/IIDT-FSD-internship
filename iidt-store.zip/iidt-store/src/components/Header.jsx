import React from 'react'

export const Header = () => {
  return (
    <div className='header'>
        <h1 className='heading'>IIDT Store</h1>
        <p>CopyRight © Akhilesh 😅</p>
    </div>
  )
}
